package com.axolens.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/** strength 0..1.2, sat multiplier, sharpen 0..1.2, warmth -0.1..0.1, target = desired mean brightness 0..1 */
data class EnhanceSpec(
    val strength: Float = 1f, val sat: Float = 1.12f, val sharpen: Float = 0.65f,
    val warmth: Float = 0f, val target: Float = 0.46f, val doc: Boolean = false,
    val clarity: Float = 0.35f, val hdr: Float = 0f, val denoise: Float = 0f,
)

data class Analysis(val score: Int, val findings: List<String>, val megapixels: Float)

/**
 * AXO on-device enhancer (no internet, no model files):
 * dehaze / auto-levels, shadow lift, gentle white balance, saturation and noise-gated sharpening.
 * Processed in strips so memory stays low on budget phones.
 */
object Enhancer {

    fun bounds(ctx: Context, uri: Uri): Pair<Int, Int> {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        return Pair(max(o.outWidth, 0), max(o.outHeight, 0))
    }

    fun loadBitmap(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val cr = ctx.contentResolver
        val (bw, bh) = bounds(ctx, uri)
        if (bw <= 0 || bh <= 0) return null
        var s = 1
        while (max(bw, bh) / (s * 2) >= maxSide) s *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val orient = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: 1
        } catch (e: Exception) { 1 }
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        val longSide = max(bmp.width, bmp.height)
        if (longSide > maxSide) { val f = maxSide.toFloat() / longSide; m.postScale(f, f) }
        if (!m.isIdentity) {
            val nb = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (nb !== bmp) bmp.recycle()
            bmp = nb
        }
        return bmp
    }

    private class Tone(val lut: IntArray, val gr: Float, val gg: Float, val gb: Float)

    private fun clamp(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    private fun buildTone(src: Bitmap, spec: EnhanceSpec): Tone {
        val ls = max(src.width, src.height)
        val f = if (ls > 320) 320f / ls else 1f
        val sw = max(1, (src.width * f).toInt()); val sh = max(1, (src.height * f).toInt())
        val s = if (f < 1f) Bitmap.createScaledBitmap(src, sw, sh, true) else src
        val px = IntArray(s.width * s.height)
        s.getPixels(px, 0, s.width, 0, 0, s.width, s.height)
        if (s !== src) s.recycle()
        val hist = IntArray(256)
        var sr = 0L; var sg = 0L; var sb = 0L
        for (c in px) {
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            hist[(77 * r + 150 * g + 29 * b) shr 8]++
            sr += r; sg += g; sb += b
        }
        val n = px.size
        var acc = 0; var lo = 0; var hi = 255; var gotLo = false
        val tLo = n * 0.004; val tHi = n * 0.996
        for (i in 0..255) {
            acc += hist[i]
            if (!gotLo && acc >= tLo) { lo = i; gotLo = true }
            if (acc >= tHi) { hi = i; break }
        }
        var loF = lo * spec.strength
        var hiF = 255f - (255 - hi) * spec.strength
        loF = min(loF, 60f); hiF = max(hiF, 140f)
        if (hiF - loF < 60f) { loF = 0f; hiF = 255f }
        var sum = 0.0
        for (i in 0..255) {
            val v = ((i - loF) / (hiF - loF)).coerceIn(0f, 1f)
            sum += hist[i] * v.toDouble()
        }
        val m = (sum / n).coerceIn(0.06, 0.94)
        var g = (ln(spec.target.toDouble()) / ln(m)).toFloat()
        g = 1f + (g - 1f) * spec.strength
        g = g.coerceIn(0.6f, 1.25f)
        val lut = IntArray(256) { i ->
            val v = ((i - loF) / (hiF - loF)).coerceIn(0f, 1f)
            (255f * v.pow(g)).toInt().coerceIn(0, 255)
        }
        val mr = sr.toFloat() / n; val mg = sg.toFloat() / n; val mb = sb.toFloat() / n
        val avg = (mr + mg + mb) / 3f
        fun gain(ch: Float) = (1f + (avg / max(ch, 1f) - 1f) * 0.5f * spec.strength).coerceIn(0.95f, 1.05f)
        return Tone(lut, gain(mr) * (1f + spec.warmth), gain(mg), gain(mb) * (1f - spec.warmth))
    }

    fun enhance(src: Bitmap, spec: EnhanceSpec): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        enhanceInPlace(out, spec)
        return out
    }

    /** Decodes at (nearly) full resolution WITHOUT rotating. Returns bitmap + EXIF orientation. */
    fun loadRaw(ctx: Context, uri: Uri, maxSide: Int): Pair<Bitmap, Int>? {
        val (bw, bh) = bounds(ctx, uri)
        if (bw <= 0 || bh <= 0) return null
        var s = 1
        while (max(bw, bh) / s > maxSide) s *= 2
        val o = BitmapFactory.Options().apply {
            inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888; inMutable = true
        }
        val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val orient = try {
            ctx.contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: 1
        } catch (e: Exception) { 1 }
        return Pair(bmp, orient)
    }

    fun applyOrientation(b: Bitmap, orient: Int): Bitmap {
        val m = Matrix()
        when (orient) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
        }
        return if (m.isIdentity) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }

    /** Variance of Laplacian on a small copy. Higher = sharper. Used to pick the best of several shots. */
    fun sharpnessOfFile(ctx: Context, f: java.io.File): Double {
        val b = loadBitmap(ctx, Uri.fromFile(f), 640) ?: return 0.0
        val w = b.width; val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        b.recycle()
        val l = IntArray(w * h) { i -> val c = px[i]; (77 * ((c shr 16) and 255) + 150 * ((c shr 8) and 255) + 29 * (c and 255)) shr 8 }
        var sum = 0.0; var sq = 0.0; var n = 0
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val lap = 4 * l[i] - l[i - w] - l[i + w] - l[i - 1] - l[i + 1]
            sum += lap; sq += lap.toDouble() * lap; n++
        }
        if (n == 0) return 0.0
        val mean = sum / n
        return sq / n - mean * mean
    }

    private fun boxBlur(src: IntArray, w: Int, rows: Int, r: Int, dst: IntArray, tmp: IntArray, col: IntArray) {
        val win = 2 * r + 1
        for (y in 0 until rows) {
            val ro = y * w
            var sum = 0
            for (k in -r..r) sum += src[ro + k.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[ro + x] = sum / win
                sum += src[ro + min(w - 1, x + r + 1)] - src[ro + max(0, x - r)]
            }
        }
        col.fill(0)
        for (k in -r..r) {
            val ro = k.coerceIn(0, rows - 1) * w
            for (x in 0 until w) col[x] += tmp[ro + x]
        }
        for (y in 0 until rows) {
            val o = y * w
            for (x in 0 until w) dst[o + x] = col[x] / win
            val a = min(rows - 1, y + r + 1) * w
            val s = max(0, y - r) * w
            for (x in 0 until w) col[x] += tmp[a + x] - tmp[s + x]
        }
    }

    /**
     * Full-resolution, low-memory enhancement done directly on the bitmap in strips:
     * tone/haze correction (same colour look as before) + fine-detail sharpening + local-contrast "clarity".
     */
    fun enhanceInPlace(bmp: Bitmap, spec: EnhanceSpec) {
        val w = bmp.width; val h = bmp.height
        val t = buildTone(bmp, spec)
        val lut = t.lut
        val strip = 128
        val mg = 12
        val buf = IntArray(w * (strip + mg))
        val luma = IntArray(w * (strip + 2 * mg))
        val blurA = IntArray(w * (strip + 2 * mg))
        val blurB = IntArray(w * (strip + 2 * mg))
        val tmp = IntArray(w * (strip + 2 * mg))
        val col = IntArray(w)
        val res = IntArray(w * strip)
        val tail = IntArray(w * mg)
        var tailRows = 0
        val satK = spec.sat
        val kFine = 0.85f * spec.sharpen
        val kClar = spec.clarity * spec.sharpen * spec.strength
        val lim = if (spec.hdr > 0f) 80 else 55
        var y0 = 0
        while (y0 < h) {
            val y1 = min(h, y0 + strip)
            val bb = min(h, y1 + mg)
            val rows = bb - y0
            bmp.getPixels(buf, 0, w, 0, y0, w, rows)
            val off = tailRows * w
            if (off > 0) System.arraycopy(tail, 0, luma, 0, off)
            for (i in 0 until rows * w) {
                val c = buf[i]
                var r = lut[clamp((((c shr 16) and 255) * t.gr).toInt())]
                var g = lut[clamp((((c shr 8) and 255) * t.gg).toInt())]
                var b = lut[clamp(((c and 255) * t.gb).toInt())]
                val l = (77 * r + 150 * g + 29 * b) shr 8
                if (spec.doc) {
                    val v = clamp((l - 70) * 255 / 120)
                    r = v; g = v; b = v
                    luma[off + i] = v
                } else {
                    if (satK != 1f) {
                        r = clamp((l + (r - l) * satK).toInt())
                        g = clamp((l + (g - l) * satK).toInt())
                        b = clamp((l + (b - l) * satK).toInt())
                    }
                    luma[off + i] = l
                }
                buf[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
            val total = tailRows + rows
            boxBlur(luma, w, total, 2, blurA, tmp, col)
            boxBlur(luma, w, total, 10, blurB, tmp, col)
            for (y in y0 until y1) {
                val lr = tailRows + (y - y0)
                val ro = (y - y0) * w
                for (x in 0 until w) {
                    val li = lr * w + x
                    val c = buf[ro + x]
                    var d = (luma[li] - blurA[li]).toFloat()
                    if (abs(d) < 3f) d *= 0.35f
                    var delta = d * kFine + (blurA[li] - blurB[li]) * kClar
                    if (spec.denoise > 0f) {
                        val dd = (luma[li] - blurA[li]).toFloat()
                        if (abs(dd) < 9f) delta -= dd * spec.denoise * 0.8f
                    }
                    if (spec.hdr > 0f) delta += (128f - blurB[li]) * spec.hdr * 0.35f
                    val di = delta.toInt().coerceIn(-lim, lim)
                    res[ro + x] = if (di == 0) c else
                        (0xFF shl 24) or
                            (clamp(((c shr 16) and 255) + di) shl 16) or
                            (clamp(((c shr 8) and 255) + di) shl 8) or
                            clamp((c and 255) + di)
                }
            }
            bmp.setPixels(res, 0, w, 0, y0, w, y1 - y0)
            if (y1 < h) {
                System.arraycopy(luma, off + (y1 - mg - y0) * w, tail, 0, mg * w)
                tailRows = mg
            }
            y0 = y1
        }
    }

    /** Estimates photo problems from a downscaled copy. These are estimates, not guarantees. */
    fun analyze(bmp: Bitmap, ow: Int, oh: Int): Analysis {
        val ls = max(bmp.width, bmp.height)
        val f = if (ls > 640) 640f / ls else 1f
        val s = Bitmap.createScaledBitmap(bmp, max(3, (bmp.width * f).toInt()), max(3, (bmp.height * f).toInt()), true)
        val w = s.width; val h = s.height
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== bmp) s.recycle()
        val l = IntArray(w * h)
        val hist = IntArray(256)
        var sr = 0.0; var sg = 0.0; var sb = 0.0
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            val y = (77 * r + 150 * g + 29 * b) shr 8
            l[i] = y; hist[y]++
            sr += r; sg += g; sb += b
        }
        val n = px.size
        var lapSum = 0.0; var lapSq = 0.0; var cnt = 0
        var noiseSum = 0.0; var noiseCnt = 0
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            val lap = 4 * l[i] - l[i - w] - l[i + w] - l[i - 1] - l[i + 1]
            lapSum += lap; lapSq += lap.toDouble() * lap; cnt++
            val gx = abs(l[i + 1] - l[i - 1]); val gy = abs(l[i + w] - l[i - w])
            if (gx + gy < 10) {
                val avg = (l[i - 1] + l[i + 1] + l[i - w] + l[i + w]) / 4
                noiseSum += abs(l[i] - avg); noiseCnt++
            }
        }
        val mean = lapSum / max(cnt, 1)
        val varLap = lapSq / max(cnt, 1) - mean * mean
        val noise = if (noiseCnt > 200) noiseSum / noiseCnt else 0.0
        var acc = 0; var p1 = 0; var p99 = 255; var got = false; var msum = 0.0
        for (i in 0..255) {
            acc += hist[i]; msum += hist[i].toDouble() * i
            if (!got && acc >= n * 0.01) { p1 = i; got = true }
            if (acc <= n * 0.99) p99 = i
        }
        val bright = msum / n
        val range = p99 - p1
        val mr = sr / n; val mg = sg / n; val mb = sb / n
        val mp = ow * oh / 1_000_000f
        val findings = ArrayList<String>()
        var score = 100
        if (varLap < 40) { findings += "Looks blurry (motion or missed focus). Enhance helps a little, but cannot fully restore it."; score -= 28 }
        else if (varLap < 110) { findings += "Slightly soft. Sharpening can help."; score -= 10 }
        if (noise > 2.5) { findings += "Visible noise / grain (common in low light)."; score -= 18 }
        else if (noise > 1.8) { findings += "Mild noise."; score -= 7 }
        if (bright < 70) { findings += "Underexposed (too dark). Shadows can be lifted."; score -= 18 }
        else if (bright > 185) { findings += "Overexposed (too bright)."; score -= 15 }
        if (range < 150) { findings += "Low contrast / hazy look. Auto-levels will fix this."; score -= 14 }
        if (abs(mr - mb) > 25) { findings += if (mr > mb) "Warm (yellow/orange) colour cast." else "Cool (blue) colour cast."; score -= 8 }
        if (mp < 2f) { findings += "Low resolution (%.1f MP). Detail is limited by the original.".format(mp); score -= 10 }
        if (findings.isEmpty()) findings += "No major problems found. This photo looks good."
        return Analysis(score.coerceIn(5, 100), findings, mp)
    }
}
