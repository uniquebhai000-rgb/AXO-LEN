package com.axolens.app

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** Software portrait: finds the person with ML Kit (on-device model) and blurs everything behind them. */
object Portrait {
    /** Returns true if a person was found and the background was blurred. */
    fun apply(bmp: Bitmap, strength: Float): Boolean {
        return try { run(bmp, strength) } catch (e: Exception) { false } catch (e: OutOfMemoryError) { false }
    }

    private fun blur3(src: FloatArray, w: Int, h: Int): FloatArray {
        val o = FloatArray(src.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f; var c = 0
            for (dy in -1..1) for (dx in -1..1) {
                val yy = y + dy; val xx = x + dx
                if (yy in 0 until h && xx in 0 until w) { s += src[yy * w + xx]; c++ }
            }
            o[y * w + x] = s / c
        }
        return o
    }

    private fun run(bmp: Bitmap, strength: Float): Boolean {
        val w = bmp.width; val h = bmp.height
        val sc = 512f / max(w, h)
        val small = Bitmap.createScaledBitmap(bmp, max(1, (w * sc).toInt()), max(1, (h * sc).toInt()), true)
        val seg = Segmentation.getClient(
            SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build())
        val mask = try {
            Tasks.await(seg.process(InputImage.fromBitmap(small, 0)))
        } finally {
            seg.close()
            small.recycle()
        }
        val mw = mask.width; val mh = mask.height
        if (mw < 2 || mh < 2) return false
        val buf = mask.buffer
        buf.rewind()
        fun valid(o: ByteOrder): Boolean {
            buf.order(o)
            val n = min(64, mw * mh)
            for (i in 0 until n) {
                val f = buf.getFloat(i * 4)
                if (f.isNaN() || f < -0.01f || f > 1.01f) return false
            }
            return true
        }
        var order = ByteOrder.nativeOrder()
        if (!valid(order)) {
            order = if (order == ByteOrder.BIG_ENDIAN) ByteOrder.LITTLE_ENDIAN else ByteOrder.BIG_ENDIAN
            if (!valid(order)) return false
        }
        buf.order(order)
        val m = FloatArray(mw * mh) { buf.getFloat(it * 4) }
        var fg = 0
        for (v in m) if (v > 0.5f) fg++
        if (fg < m.size * 0.03f) return false

        val sm = blur3(blur3(m, mw, mh), mw, mh)
        val mm = FloatArray(sm.size) { ((sm[it] - 0.35f) / 0.3f).coerceIn(0f, 1f) }

        val s = 220f - 170f * strength.coerceIn(0f, 1f)
        val sc2 = s / max(w, h)
        val tiny = Bitmap.createScaledBitmap(bmp, max(2, (w * sc2).toInt()), max(2, (h * sc2).toInt()), true)
        val big = Bitmap.createScaledBitmap(tiny, w, h, true)
        tiny.recycle()

        val xi = IntArray(w); val xf = FloatArray(w)
        for (x in 0 until w) {
            val fx = x * (mw - 1f) / max(1, w - 1)
            xi[x] = min(mw - 2, fx.toInt()).coerceAtLeast(0)
            xf[x] = fx - xi[x]
        }
        val strip = 128
        val a = IntArray(w * strip)
        val b = IntArray(w * strip)
        var y0 = 0
        while (y0 < h) {
            val y1 = min(h, y0 + strip)
            val rows = y1 - y0
            bmp.getPixels(a, 0, w, 0, y0, w, rows)
            big.getPixels(b, 0, w, 0, y0, w, rows)
            for (yy in 0 until rows) {
                val fy = (y0 + yy) * (mh - 1f) / max(1, h - 1)
                val yi = min(mh - 2, fy.toInt()).coerceAtLeast(0)
                val yf = fy - yi
                val r0 = yi * mw; val r1 = (yi + 1) * mw
                for (x in 0 until w) {
                    val i = yy * w + x
                    val x0 = xi[x]; val fxx = xf[x]
                    val v = (mm[r0 + x0] * (1 - fxx) + mm[r0 + x0 + 1] * fxx) * (1 - yf) +
                        (mm[r1 + x0] * (1 - fxx) + mm[r1 + x0 + 1] * fxx) * yf
                    if (v >= 0.999f) continue
                    val ca = a[i]; val cb = b[i]
                    val r = (((ca shr 16) and 255) * v + ((cb shr 16) and 255) * (1 - v)).toInt()
                    val g = (((ca shr 8) and 255) * v + ((cb shr 8) and 255) * (1 - v)).toInt()
                    val bl = ((ca and 255) * v + (cb and 255) * (1 - v)).toInt()
                    a[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
                }
            }
            bmp.setPixels(a, 0, w, 0, y0, w, rows)
            y0 = y1
        }
        big.recycle()
        return true
    }
}
