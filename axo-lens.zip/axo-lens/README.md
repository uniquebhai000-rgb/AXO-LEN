# AXO LENS - Capture Beyond Limits.

## Get the APK (no Android Studio needed)
1. Upload this project to GitHub (zip named `axo-lens.zip` in repo root, or all files).
2. Actions -> Build APK -> Run workflow.
3. Download artifact `axo-lens-debug-apk`, extract, install.

## Done (v0.2.0)
- Camera: max-resolution capture, tap focus, pinch zoom, EV, flash, TORCH, timer 3/5/10, grid, 4:3 / 16:9, front/back, volume-key shutter
- Modes: Photo, Portrait*, Night*, HDR*, Landscape, Food, Scan, Pro (ISO/shutter/WB where supported), Burst, Video
  (* uses phone hardware mode when available, else AXO software enhance)
- AXO Enhance: dehaze / auto-levels, shadow lift, white-balance nudge, saturation, noise-gated sharpen (offline)
- Video: quality picker (only supported), audio toggle, pause/resume, timer, torch
- Gallery: photos/videos/favorites, date groups, pinch-zoom viewer, share, info, delete, edit
- AI Studio: Photo Doctor (analysis + before/after + save copy), Editor (filters+intensity, light, colour, vignette, rotate/flip, undo/redo, compare)
- Settings, device optimizer report, privacy (no INTERNET permission)

## Not built yet
Panorama, RAW/DNG, slow motion, level indicator, neural super-resolution (needs model files), segmentation/background blur,
object removal, video enhancer, cloud AI, Room/DI, automated tests, release signing.
