package com.axolens.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

class BoolPref(private val sp: SharedPreferences, private val key: String, def: Boolean) {
    private val st = mutableStateOf(sp.getBoolean(key, def))
    var value: Boolean
        get() = st.value
        set(v) { st.value = v; sp.edit().putBoolean(key, v).apply() }
}

class FloatPref(private val sp: SharedPreferences, private val key: String, def: Float) {
    private val st = mutableStateOf(sp.getFloat(key, def))
    var value: Float
        get() = st.value
        set(v) { st.value = v; sp.edit().putFloat(key, v).apply() }
}

object Prefs {
    private lateinit var sp: SharedPreferences
    lateinit var autoEnhance: BoolPref
    lateinit var keepOriginal: BoolPref
    lateinit var grid: BoolPref
    lateinit var haptics: BoolPref
    lateinit var ratio169: BoolPref
    lateinit var audio: BoolPref
    lateinit var cheese: BoolPref
    lateinit var palm: BoolPref
    lateinit var ultra: BoolPref
    lateinit var strength: FloatPref
    val favorites = mutableStateOf<Set<String>>(emptySet())

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("axo", Context.MODE_PRIVATE)
        autoEnhance = BoolPref(sp, "auto", true)
        keepOriginal = BoolPref(sp, "keep", true)
        grid = BoolPref(sp, "grid", true)
        haptics = BoolPref(sp, "haptics", true)
        ratio169 = BoolPref(sp, "r169", false)
        audio = BoolPref(sp, "audio", true)
        cheese = BoolPref(sp, "cheese", false)
        palm = BoolPref(sp, "palm", false)
        ultra = BoolPref(sp, "ultra", true)
        strength = FloatPref(sp, "strength", 1f)
        favorites.value = sp.getStringSet("favs", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleFav(id: String) {
        val n = favorites.value.toMutableSet()
        if (!n.add(id)) n.remove(id)
        favorites.value = n
        sp.edit().putStringSet("favs", n).apply()
    }
}

object ShutterBus { var action: (() -> Unit)? = null }
