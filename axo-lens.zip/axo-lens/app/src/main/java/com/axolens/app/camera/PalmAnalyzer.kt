package com.axolens.app.camera

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy

/**
 * Experimental "show palm" shutter. Looks for a large skin-coloured area held steady for ~1.2 s.
 * It is a simple colour heuristic (no AI model), so it can be fooled by a face or arm very close to the lens.
 */
class PalmAnalyzer(
    private val onProgress: (Float) -> Unit,
    private val onPalm: () -> Unit,
) : ImageAnalysis.Analyzer {
    private var n = 0
    private var holdStart = 0L
    private var lastFire = 0L

    override fun analyze(image: ImageProxy) {
        try {
            n++
            if (n % 3 == 0) {
                val ratio = skinRatio(image)
                val now = System.currentTimeMillis()
                if (ratio >= 0.30f && now - lastFire > 3500L) {
                    if (holdStart == 0L) holdStart = now
                    val p = ((now - holdStart) / 1200f).coerceIn(0f, 1f)
                    onProgress(p)
                    if (p >= 1f) {
                        lastFire = now; holdStart = 0L
                        onProgress(0f)
                        onPalm()
                    }
                } else {
                    holdStart = 0L
                    onProgress(0f)
                }
            }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun skinRatio(img: ImageProxy): Float {
        val yp = img.planes[0]; val up = img.planes[1]; val vp = img.planes[2]
        val yb = yp.buffer; val ub = up.buffer; val vb = vp.buffer
        val w = img.width; val h = img.height
        var skin = 0; var total = 0
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val yv = yb.get(y * yp.rowStride + x * yp.pixelStride).toInt() and 255
                val cb = ub.get((y / 2) * up.rowStride + (x / 2) * up.pixelStride).toInt() and 255
                val cr = vb.get((y / 2) * vp.rowStride + (x / 2) * vp.pixelStride).toInt() and 255
                if (yv > 50 && cb in 85..125 && cr in 138..175) skin++
                total++
                x += 4
            }
            y += 4
        }
        return if (total == 0) 0f else skin.toFloat() / total
    }
}
