package com.axolens.app.camera

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Listens for the word "cheese" only while the camera screen is open and the toggle is on. */
class VoiceShutter(private val ctx: Context, private val onHeard: () -> Unit) {
    private var rec: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var active = false
    private var weMuted = false
    private val keys = listOf("cheese", "chees", "cheez", "chiz", "cheeze", "चीज", "चीस", "चिज", "चीज़")

    fun start() {
        if (active) return
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) return
        active = true
        muteBeep(true)
        listen()
    }

    fun stop() {
        active = false
        handler.removeCallbacksAndMessages(null)
        try { rec?.destroy() } catch (_: Exception) { }
        rec = null
        muteBeep(false)
    }

    private fun muteBeep(mute: Boolean) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (mute) {
                if (!am.isStreamMute(AudioManager.STREAM_MUSIC)) {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                    weMuted = true
                }
            } else if (weMuted) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                weMuted = false
            }
        } catch (_: Exception) { }
    }

    private fun listen() {
        if (!active) return
        try { rec?.destroy() } catch (_: Exception) { }
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { active = false; return }
                restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 400L)
            }
            override fun onResults(results: Bundle?) { check(results); restart(300L) }
            override fun onPartialResults(partialResults: Bundle?) { check(partialResults) }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { r.startListening(i) } catch (e: Exception) { restart(1000L) }
    }

    private fun restart(ms: Long) {
        if (!active) return
        handler.postDelayed({ listen() }, ms)
    }

    private fun check(b: Bundle?) {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
        for (s in list) {
            val t = s.lowercase()
            if (keys.any { t.contains(it) }) { onHeard(); return }
        }
    }
}
