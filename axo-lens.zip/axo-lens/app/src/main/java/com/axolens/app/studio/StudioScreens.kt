@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
package com.axolens.app.studio

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axolens.app.Analysis
import com.axolens.app.EnhanceSpec
import com.axolens.app.Enhancer
import com.axolens.app.MediaSaver
import com.axolens.app.Prefs
import com.axolens.app.ui.AxoBlue
import com.axolens.app.ui.AxoCard
import com.axolens.app.ui.AxoYellow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun StudioScreen(onDoctor: (Uri) -> Unit, onEditor: (Uri) -> Unit) {
    val pickDoctor = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(onDoctor) }
    val pickEditor = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { it?.let(onEditor) }
    val req = PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("AI Studio", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Everything runs on your phone. Nothing is uploaded.", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        StudioCard("Photo Doctor", "Pick a photo. Aura checks blur, noise, exposure, haze and colour, then fixes what it can in one tap.") {
            pickDoctor.launch(req)
        }
        Spacer(Modifier.height(12.dp))
        StudioCard("Photo Editor", "Filters with intensity, brightness, contrast, colour, warmth, vignette, rotate, flip, Aura Enhance, undo/redo. Saves as a new copy.") {
            pickEditor.launch(req)
        }
        Spacer(Modifier.height(16.dp))
        Text("Honest note: enhancement improves what the sensor captured. It cannot invent detail that was never recorded, " +
            "and a badly blurred photo cannot be fully restored.", color = Color.Gray, fontSize = 12.sp)
    }
}

@Composable
private fun StudioCard(title: String, desc: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(AxoCard).clickable(onClick = onClick).padding(18.dp)) {
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(desc, color = Color.LightGray, fontSize = 13.sp)
    }
}

@Composable
fun DoctorScreen(uri: Uri, onEdit: (Uri) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onClose)
    var before by remember { mutableStateOf<Bitmap?>(null) }
    var after by remember { mutableStateOf<Bitmap?>(null) }
    var analysis by remember { mutableStateOf<Analysis?>(null) }
    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf(false) }

    LaunchedEffect(uri) {
        withContext(Dispatchers.Default) {
            try {
                val (ow, oh) = Enhancer.bounds(ctx, uri)
                val b = Enhancer.loadBitmap(ctx, uri, 1024)
                if (b == null) error = true else { analysis = Enhancer.analyze(b, ow, oh); before = b }
            } catch (e: Throwable) { error = true }
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black).verticalScroll(rememberScrollState()).padding(16.dp)) {
        IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
        Text("Photo Doctor", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (error) Text("Could not open this photo.", color = Color.Red)
        val a = analysis
        if (a == null && !error) CircularProgressIndicator()
        if (a != null) {
            Text("Quality score: ${a.score}/100", color = if (a.score >= 75) Color(0xFF30D158) else AxoYellow,
                fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            a.findings.forEach { Text("• $it", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp)) }
            Text("These are automatic estimates.", color = Color.Gray, fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                before?.let { Column(Modifier.weight(1f)) {
                    Text("Before", color = Color.Gray, fontSize = 12.sp)
                    Image(it.asImageBitmap(), "Before", Modifier.fillMaxWidth().aspectRatio(it.width.toFloat() / it.height), contentScale = ContentScale.Fit)
                } }
                after?.let { Column(Modifier.weight(1f)) {
                    Text("After", color = AxoYellow, fontSize = 12.sp)
                    Image(it.asImageBitmap(), "After", Modifier.fillMaxWidth().aspectRatio(it.width.toFloat() / it.height), contentScale = ContentScale.Fit)
                } }
            }
            Spacer(Modifier.height(16.dp))
            if (working) CircularProgressIndicator()
            else {
                Button(onClick = {
                    val b = before
                    if (b == null) return@Button
                    working = true
                    scope.launch {
                        after = withContext(Dispatchers.Default) { runCatching { Enhancer.enhance(b, EnhanceSpec(Prefs.strength.value)) }.getOrNull() }
                        working = false
                    }
                }, Modifier.fillMaxWidth()) { Text("One-tap enhance (preview)") }
                if (after != null) {
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        working = true
                        scope.launch {
                            val saved = withContext(Dispatchers.Default) {
                                runCatching {
                                    val full = Enhancer.loadBitmap(ctx, uri, 4096)!!
                                    val out = Enhancer.enhance(full, EnhanceSpec(Prefs.strength.value))
                                    full.recycle()
                                    val u = MediaSaver.saveBitmap(ctx, out, MediaSaver.newName("AXO_fixed"), 95)
                                    out.recycle(); u
                                }.getOrNull()
                            }
                            working = false
                            Toast.makeText(ctx, if (saved != null) "Saved a new enhanced copy. Original untouched." else "Could not save", Toast.LENGTH_LONG).show()
                        }
                    }, Modifier.fillMaxWidth()) { Text("Save enhanced copy") }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { onEdit(uri) }, Modifier.fillMaxWidth()) { Text("Open in editor") }
            }
        }
    }
}

private enum class Tool { FILTERS, LIGHT, COLOR, EFFECTS, TRANSFORM, AI }

@Composable
fun EditorScreen(uri: Uri, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    BackHandler(onBack = onClose)
    var base by remember { mutableStateOf<Bitmap?>(null) }
    var enhanced by remember { mutableStateOf<Bitmap?>(null) }
    var params by remember { mutableStateOf(EditParams()) }
    val undo = remember { mutableStateListOf<EditParams>() }
    val redo = remember { mutableStateListOf<EditParams>() }
    var dragStart by remember { mutableStateOf<EditParams?>(null) }
    var showOrig by remember { mutableStateOf(false) }
    var tool by remember { mutableStateOf(Tool.FILTERS) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(uri) { base = withContext(Dispatchers.Default) { runCatching { Enhancer.loadBitmap(ctx, uri, 1600) }.getOrNull() } }
    LaunchedEffect(params.enhance, base) {
        val b = base
        if (params.enhance && b != null && enhanced == null) {
            enhanced = withContext(Dispatchers.Default) { runCatching { Enhancer.enhance(b, EnhanceSpec(Prefs.strength.value)) }.getOrNull() }
        }
    }

    fun live(np: EditParams) { if (dragStart == null) dragStart = params; params = np }
    fun done() { dragStart?.let { undo.add(it); redo.clear() }; dragStart = null }
    fun commit(np: EditParams) { undo.add(params); redo.clear(); params = np }

    fun save() {
        saving = true
        scope.launch {
            val u = withContext(Dispatchers.Default) {
                runCatching {
                    val full = Enhancer.loadBitmap(ctx, uri, 4096)!!
                    val out = renderFinal(full, params)
                    MediaSaver.saveBitmap(ctx, out, MediaSaver.newName("AXO_edit"), 95).also { out.recycle() }
                }.getOrNull()
            }
            saving = false
            Toast.makeText(ctx, if (u != null) "Saved as a new copy" else "Could not save", Toast.LENGTH_LONG).show()
            if (u != null) onClose()
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Default.ArrowBack, "Close", tint = Color.White) }
            Spacer(Modifier.weight(1f))
            IconButton(enabled = undo.isNotEmpty(), onClick = { redo.add(params); params = undo.removeAt(undo.size - 1) }) {
                Icon(Icons.Default.Undo, "Undo", tint = if (undo.isNotEmpty()) Color.White else Color.DarkGray)
            }
            IconButton(enabled = redo.isNotEmpty(), onClick = { undo.add(params); params = redo.removeAt(redo.size - 1) }) {
                Icon(Icons.Default.Redo, "Redo", tint = if (redo.isNotEmpty()) Color.White else Color.DarkGray)
            }
            Text("Hold: original", color = Color.White, fontSize = 12.sp,
                modifier = Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF2A2A2E))
                    .pointerInput(Unit) { detectTapGestures(onPress = { showOrig = true; tryAwaitRelease(); showOrig = false }) }
                    .padding(horizontal = 12.dp, vertical = 8.dp))
            if (saving) CircularProgressIndicator(Modifier.padding(8.dp).size(24.dp))
            else IconButton(onClick = { save() }) { Icon(Icons.Default.Save, "Save copy", tint = AxoYellow) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            val b = base
            if (b == null) CircularProgressIndicator()
            else {
                val src = if (!showOrig && params.enhance) (enhanced ?: b) else b
                val shown = remember(src, params.rot, params.flip, showOrig) {
                    if (showOrig) src else transformBitmap(src, params.rot, params.flip)
                }
                val e = effective(params)
                val cf = remember(e.toList(), showOrig) {
                    if (showOrig) null else ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix(buildMatrix(e).array))
                }
                Box(Modifier.aspectRatio(shown.width.toFloat() / shown.height)) {
                    Image(shown.asImageBitmap(), "Preview", Modifier.fillMaxSize(), contentScale = ContentScale.Fit, colorFilter = cf)
                    if (!showOrig && e[4] > 0f) Box(Modifier.fillMaxSize().background(Brush.radialGradient(
                        0f to Color.Transparent, 0.55f to Color.Transparent,
                        1f to Color.Black.copy(alpha = (e[4].coerceAtMost(100f) / 100f * 0.8f)))))
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(Color(0xFF0E0E10)).padding(12.dp)) {
            when (tool) {
                Tool.FILTERS -> {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(FILTERS.keys.toList()) { n ->
                            Text(n, color = if (params.filter == n) Color.Black else Color.White, fontSize = 13.sp,
                                modifier = Modifier.clip(RoundedCornerShape(50))
                                    .background(if (params.filter == n) AxoYellow else Color(0xFF2A2A2E))
                                    .clickable { commit(params.copy(filter = n, fK = 1f)) }.padding(horizontal = 14.dp, vertical = 8.dp))
                        }
                    }
                    Text("Intensity ${(params.fK * 100).toInt()}%", color = Color.White, fontSize = 12.sp)
                    Slider(params.fK, { live(params.copy(fK = it)) }, valueRange = 0f..1.5f, onValueChangeFinished = { done() })
                }
                Tool.LIGHT -> {
                    Param("Brightness", params.bright, { live(params.copy(bright = it)) }, { done() })
                    Param("Contrast", params.contrast, { live(params.copy(contrast = it)) }, { done() })
                }
                Tool.COLOR -> {
                    Param("Saturation", params.sat, { live(params.copy(sat = it)) }, { done() })
                    Param("Warmth", params.warm, { live(params.copy(warm = it)) }, { done() })
                }
                Tool.EFFECTS -> {
                    Text("Vignette ${params.vignette.toInt()}", color = Color.White, fontSize = 12.sp)
                    Slider(params.vignette, { live(params.copy(vignette = it)) }, valueRange = 0f..100f, onValueChangeFinished = { done() })
                }
                Tool.TRANSFORM -> Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    IconButton(onClick = { commit(params.copy(rot = (params.rot + 1) % 4)) }) { Icon(Icons.Default.RotateRight, "Rotate", tint = Color.White) }
                    IconButton(onClick = { commit(params.copy(flip = !params.flip)) }) { Icon(Icons.Default.Flip, "Flip", tint = Color.White) }
                }
                Tool.AI -> {
                    Text(if (params.enhance) "Aura Enhance is ON" else "Aura Enhance is OFF", color = Color.White)
                    Text("Removes haze, lifts shadows, balances colour, sharpens without boosting noise.", color = Color.Gray, fontSize = 12.sp)
                    Button(onClick = { commit(params.copy(enhance = !params.enhance)) }) { Text(if (params.enhance) "Turn off" else "Turn on") }
                }
            }
            Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(Tool.values().toList()) { t ->
                    Text(t.name.lowercase().replaceFirstChar { it.uppercase() }, fontSize = 13.sp,
                        color = if (t == tool) AxoBlue else Color.White,
                        modifier = Modifier.clickable { tool = t }.padding(horizontal = 10.dp, vertical = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun Param(name: String, value: Float, onChange: (Float) -> Unit, onDone: () -> Unit) {
    Text("$name ${value.toInt()}", color = Color.White, fontSize = 12.sp)
    Slider(value, onChange, valueRange = -100f..100f, onValueChangeFinished = onDone)
}
